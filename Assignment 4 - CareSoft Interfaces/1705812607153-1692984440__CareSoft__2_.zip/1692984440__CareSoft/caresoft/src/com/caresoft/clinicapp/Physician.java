package com.caresoft.clinicapp;

import java.util.ArrayList;
import java.util.Date;

public class Physician extends User implements HIPAACompliantUser {
    private ArrayList<String> patientNotes;

    // Constructor that takes an ID
    public Physician(Integer id) {
        super(); // Call the constructor of the superclass (User)
        this.patientNotes = new ArrayList<>();
    }

    // Implementing methods from the HIPAACompliantUser interface
    @Override
    public boolean assignPin(int pin) {
        if (pin > 999 && pin < 10000) {
            // Valid PIN range (assuming 4-digit PIN)
            this.pin = pin;
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean accessAuthorized(Integer confirmedAuthID) {
        // Physician can access if the confirmedAuthID matches the physician's ID
        return confirmedAuthID.equals(this.id) || confirmedAuthID.equals(this.pin);
    }

    // Method to add new patient notes
    public void newPatientNotes(String notes, String patientName, Date date) {
        String report = String.format("Datetime Submitted: %s \n", date);
        report += String.format("Reported By ID: %s\n", this.id);
        report += String.format("Patient Name: %s\n", patientName);
        report += String.format("Notes: %s \n", notes);
        this.patientNotes.add(report);
    }

    // Setters & Getters
    public ArrayList<String> getPatientNotes() {
        return patientNotes;
    }

    // Other setters and getters as needed
}