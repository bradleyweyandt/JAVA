package com.caresoft.clinicapp;

import java.util.ArrayList;
import java.util.Date;

public class AdminUser extends User implements HIPAACompliantUser, HIPAACompliantAdmin {
    private Integer employeeID;
    private String role;
    private ArrayList<String> securityIncidents;

    // Constructor that takes an ID and a role
    public AdminUser(Integer id, String role) {
        super(); // Call the constructor of the superclass (User)
        this.employeeID = id;
        this.role = role;
        this.securityIncidents = new ArrayList<>();
    }

    // Implementing methods from the HIPAACompliantUser interface
    @Override
    public boolean assignPin(int pin) {
        // AdminUser can have any PIN, so return true
        this.pin = pin;
        return true;
    }

    @Override
    public boolean accessAuthorized(Integer confirmedAuthID) {
        // AdminUser can access if the confirmedAuthID matches either the admin's ID or PIN
        return confirmedAuthID.equals(this.id) || confirmedAuthID.equals(this.pin);
    }

    // Implementing methods from the HIPAACompliantAdmin interface
    @Override
    public ArrayList<String> reportSecurityIncidents() {
        // Implementation of reporting security incidents for AdminUser (HIPAACompliantAdmin)
        return securityIncidents;
    }

    // Additional method to assign security clearance
    public void assignSecurityClearance(int level) {
        // Implementation of assigning security clearance for AdminUser (HIPAACompliantAdmin)
        // You can customize this based on your requirements
    }

    // Setters & Getters
    public Integer getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Integer employeeID) {
        this.employeeID = employeeID;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Other methods
    public void newIncident(String notes) {
        String report = String.format(
                "Datetime Submitted: %s \n,  Reported By ID: %s\n Notes: %s \n",
                new Date(), this.id, notes
        );
        securityIncidents.add(report);
    }

    public void authIncident() {
        String report = String.format(
                "Datetime Submitted: %s \n,  ID: %s\n Notes: %s \n",
                new Date(), this.id, "AUTHORIZATION ATTEMPT FAILED FOR THIS USER"
        );
        securityIncidents.add(report);
    }

    public ArrayList<String> getSecurityIncidents() {
        return securityIncidents;
    }

    // Other getters and setters as needed
}