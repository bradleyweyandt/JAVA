// Bat class extending Mammal
class Bat extends Mammal {
    public Bat() {
        this.energy = 300;
    }

    public void fly() {
        System.out.println("Bat is airborne. Energy decreased by 50.");
        this.energy -= 50;
    }

    public void eatHumans() {
        System.out.println("Bat ate humans. Energy increased by 25.");
        this.energy += 25;
    }

    public void attackTown() {
        System.out.println("Bat attacked a town. Energy decreased by 100.");
        this.energy -= 100;
    }
}