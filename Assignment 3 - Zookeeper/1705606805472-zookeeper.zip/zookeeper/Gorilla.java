// Gorilla class extending Mammal
class Gorilla extends Mammal {
    public void throwSomething() {
        System.out.println("Gorilla threw something. Energy decreased by 5.");
        this.energy -= 5;
    }

    public void eatBananas() {
        System.out.println("Gorilla ate bananas. Energy increased by 10.");
        this.energy += 10;
    }

    public void climb() {
        System.out.println("Gorilla climbed a tree. Energy decreased by 10.");
        this.energy -= 10;
    }
}