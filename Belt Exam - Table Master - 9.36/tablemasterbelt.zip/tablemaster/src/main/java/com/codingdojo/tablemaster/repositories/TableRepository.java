package com.codingdojo.tablemaster.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.codingdojo.tablemaster.models.TableModel;
import com.codingdojo.tablemaster.models.User;

public interface TableRepository extends CrudRepository<TableModel, Long> {

	TableModel findById(long id);
	public List<TableModel> findAll();
	List<TableModel> findByUser(User user);
	
	
}
