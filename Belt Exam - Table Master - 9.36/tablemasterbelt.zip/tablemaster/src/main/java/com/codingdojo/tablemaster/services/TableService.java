package com.codingdojo.tablemaster.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.tablemaster.models.TableModel;
import com.codingdojo.tablemaster.models.User;
import com.codingdojo.tablemaster.repositories.TableRepository;

@Service
public class TableService {
    
    @Autowired
    private TableRepository tRepo;
    
    // method create a new table
    public void createTable(TableModel t) {
        tRepo.save(t);
    }

    // m retrieve all tables
    public List<TableModel> allTables() {
        return tRepo.findAll();
    }
    
    // m find table by ID
    public TableModel findTable(Long id) {
        Optional<TableModel> t = tRepo.findById(id);
        return t.orElse(null);
    }
    
    // m to delete table by ID
    public void destroy(Long id) {
        tRepo.deleteById(id);
    }
    
    // m to find all tables associated with a specific user by their user ID
    public List<TableModel> findTablesByUserId(Long userId) {
        User user = new User();
        user.setId(userId);
        return tRepo.findByUser(user);
    }
    
    // m to update existing table
    public boolean updateTable(TableModel table) {
        // check if the table exists in the DB
        Optional<TableModel> existingTableOptional = tRepo.findById(table.getId());
        if (existingTableOptional.isPresent()) {
            // get the existing table entity from the optional
            TableModel existingTable = existingTableOptional.get();
            
            // update the fields of the existing table entity with the new values
            existingTable.setGuestName(table.getGuestName());
            existingTable.setNumberOfGuests(table.getNumberOfGuests());
            existingTable.setNotes(table.getNotes());
            
            // save the updated table entity
            tRepo.save(existingTable);
            
            // return successful update
            return true;
        } else {
            // return false that table with the given ID is not found
            return false;
        }
    }
    // m to find table by its ID
    public TableModel findById(Long id) {
        return tRepo.findById(id).orElse(null);
    }
    // m to find all tables of a specific user
    public List<TableModel> findByUser(User user) {
        return tRepo.findByUser(user);
    }
}
