package com.codingdojo.tablemaster.services;

import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.codingdojo.tablemaster.models.LoginUser;
import com.codingdojo.tablemaster.models.User;
import com.codingdojo.tablemaster.repositories.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository uRepo;

	// method register a new user
	public User register(User u, BindingResult result) {
		// check passwords match
		if (!u.getConfirm().equals(u.getPassword())) {
			result.rejectValue("confirm", null, "Passwords must match.");
		}
		
		// check if email already in use
		Optional<User> thisUser = uRepo.findByEmail(u.getEmail());
		if (thisUser.isPresent()) {
			result.rejectValue("email", null, "Email already in use.");
		}
		
		// return null if there errors
		if (result.hasErrors()) {
			return null;
		}
		
		// hash and set password, save user to database
		String hash = BCrypt.hashpw(u.getPassword(), BCrypt.gensalt());
		u.setPassword(hash);
		uRepo.save(u);
		
		return u;
	}
	
	// method to log in user
	public User login(LoginUser newLoginObject, BindingResult result) {
		// find user in the DB by email
		Optional<User> thisUser = uRepo.findByEmail(newLoginObject.getEmail());
		
		// reject user if not found
		if (thisUser.isEmpty()) {
			result.rejectValue("email", null, "Email/Password Incorrect.");
		} else {
			// reject password not match
			Boolean isValid = BCrypt.checkpw(newLoginObject.getPassword(), thisUser.get().getPassword());
			if (!isValid) {
				result.rejectValue("password", null, "Email/Password Incorrect.");
			}
		}
		
		// return null if errors
		if (result.hasErrors()) {
			return null;
		}
		
		// otherwise return the user object
		return thisUser.get();
	}
    
    // method to find user by ID
    public User findUser(Long id) {
    	Optional<User> u = uRepo.findById(id);
    	if (u.isEmpty()) {
    		return null;
    	}
    	return u.get();
    }
}