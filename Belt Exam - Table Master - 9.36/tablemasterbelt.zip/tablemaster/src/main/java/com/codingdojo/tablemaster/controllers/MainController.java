package com.codingdojo.tablemaster.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.tablemaster.models.LoginUser;
import com.codingdojo.tablemaster.models.TableModel;
import com.codingdojo.tablemaster.models.User;
import com.codingdojo.tablemaster.services.TableService;
import com.codingdojo.tablemaster.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class MainController {
	
    @Autowired
    private UserService uService;

    @Autowired
    private TableService tService;

    // login registration*****************************************************
    
    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        Long id = (Long) session.getAttribute("userId");
        if(id != null) {
            return "redirect:/dashboard";
        }
        model.addAttribute("loginObject", new LoginUser());
        model.addAttribute("registerObject", new User());
        return "index.jsp";
    }

    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("loginObject") LoginUser loginUser,
            BindingResult result, Model model, HttpSession session) {
        User thisUser = uService.login(loginUser, result);
        if(result.hasErrors()) {
            model.addAttribute("registerObject", new User());
            return "index.jsp";
        }
        session.setAttribute("userId", thisUser.getId());
        return "redirect:/dashboard";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registerObject") User user,
            BindingResult result, Model model, HttpSession session) {
        User thisUser = uService.register(user, result);
        if(result.hasErrors()) {
            model.addAttribute("loginObject", new LoginUser());
            return "index.jsp";
        }
        session.setAttribute("userId", thisUser.getId());
        return "redirect:/dashboard";
    }

    // crud*****************************************************
    
    // create
    
    @GetMapping("/tables/new")
    public String createPage(Model model, HttpSession session) {
        model.addAttribute("tableObject", new TableModel());
        return "create.jsp";
    }

    // read
    
    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if(userId == null) {
            return "redirect:/";
        }
        User loggedInUser = uService.findUser(userId);
        model.addAttribute("firstName", loggedInUser.getFirstName());
        model.addAttribute("tables", tService.allTables());
        return "dashboard.jsp";
    }

    // create table
    
    @PostMapping("/tables")
    public String createTable(@Valid @ModelAttribute("tableObject") TableModel t,
            BindingResult result) {
        if(result.hasErrors()) {
            return "create.jsp";
        }
        tService.createTable(t);
        return "redirect:/dashboard";
    }

    // update
    
    @GetMapping("/tables/{id}/edit")
    public String editTable(Model model, HttpSession session, @PathVariable("id") Long id) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }
        TableModel t = tService.findById(id);
        if (t == null) {
            return "redirect:/dashboard";
        }
        model.addAttribute("loggedInUser", userId);
        model.addAttribute("tableObject", t);
        return "update.jsp";
    }

    @PostMapping("/tables/{id}/edit")
    public String updateTable(Model model, HttpSession session, @PathVariable("id") Long id,
            @Valid @ModelAttribute("tableObject") TableModel table, BindingResult result) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }
        TableModel existingTable = tService.findTable(id);
        if (existingTable == null || !userId.equals(existingTable.getUser().getId())) {
            return "redirect:/dashboard";
        }
        if (result.hasErrors()) {
            model.addAttribute("tableObject", table);
            return "update.jsp";
        }
        tService.updateTable(table);
        return "redirect:/dashboard";
    }

    // delete
    
    @DeleteMapping("/tables/{id}/delete")
    public String deleteTable(Model model, HttpSession session, @PathVariable("id") Long id) {
        tService.destroy(id);
        return "redirect:/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/alltables")
    public String viewAllTables(Model model) {
        List<TableModel> allTables = tService.allTables();
        model.addAttribute("allTables", allTables);
        return "alltables.jsp";
    }
}
