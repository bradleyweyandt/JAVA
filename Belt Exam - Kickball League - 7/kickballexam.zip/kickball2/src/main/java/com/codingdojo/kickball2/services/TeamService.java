package com.codingdojo.kickball2.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.codingdojo.kickball2.models.Team;
import com.codingdojo.kickball2.repositories.TeamRepository;

@Service
public class TeamService {
    private final TeamRepository teamRepo;
    
    public TeamService(TeamRepository teamRepo) {
        this.teamRepo = teamRepo;
    }
    
    public List<Team> allTeams(){
        return teamRepo.findAll();
    }
    
    public Team createTeam(Team team) {
        return teamRepo.save(team);
    }
    
    public Team singleTeam(Long id) { 
        Optional<Team> optTeam = teamRepo.findById(id);
        if(optTeam.isPresent()) {
            return optTeam.get();
        } else {
            return null;
        }
    }
    
    public Team updateTeam(Team team) {
        Optional<Team> optTeam = teamRepo.findById(team.getId());
        if(optTeam.isPresent()) {
            Team thisTeam = optTeam.get();
            
            thisTeam.setName(team.getName());
            thisTeam.setSkill(team.getSkill());
            thisTeam.setDay(team.getDay());
            thisTeam.setId(team.getId());
            
            return teamRepo.save(thisTeam);
        } else {
            return null;
        }
    }
    
    public void deleteTeam(Long id) {
        teamRepo.deleteById(id);
    }
}
