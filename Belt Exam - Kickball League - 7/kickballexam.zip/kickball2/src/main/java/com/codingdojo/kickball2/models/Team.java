package com.codingdojo.kickball2.models;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="team")
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotNull(message = "Team Name cannot be blank")
    @Size(min=2,max=100,message="Team Name must be between 2 and 100 characters")
    private String name;
    
    @NotNull
    private Integer skill;
    
    @NotNull(message = "Day cannot be blank")
    @Size(min=2,max=200,message="Day must be between 2 and 200 characters")
    private String day;
    
    @Column(updatable=false)
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date createdAt;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date updatedAt;
    
    // RELATIONSHIPS
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="user_id")
    private User user;
    
    // CONTROLLERS
    public Team(Long id, String name, Integer skill, String day, Date createdAt, Date updatedAt) {
        super();
        this.id = id;
        this.name = name;
        this.skill = skill;
        this.day = day;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    
    public Team(Long id, String name, Integer skill, String day, Date createdAt, Date updatedAt, User user) {
        super();
        this.id = id;
        this.name = name;
        this.skill = skill;
        this.day = day;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.user = user;
    }


    public Team(String name, Integer skill, String day, User user) {
        super();
        this.name = name;
        this.skill = skill;
        this.day = day;
        this.user = user;
    }


    public Team() {
        super();
    }
    public Team(String name, Integer skill, String day) {
        super();
        this.name = name;
        this.skill = skill;
        this.day = day;
    }
    
    // GETTERS / SETTERS
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getSkill() {
        return skill;
    }
    public void setSkill(Integer skill) {
        this.skill = skill;
    }
    public String getDay() {
        return day;
    }
    public void setDay(String day) {
        this.day = day;
    }
    public Date getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    public Date getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public User getUser() {
        return user;
    }


    public void setUser(User user) {
        this.user = user;
    }


    @PrePersist
    protected void onCreate(){
        this.createdAt = new Date();
    }
    @PreUpdate
    protected void onUpdate(){
        this.updatedAt = new Date();
    }
    
}
