package com.codingdojo.kickball2.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.kickball2.models.LoginUser;
import com.codingdojo.kickball2.models.Team;
import com.codingdojo.kickball2.models.User;
import com.codingdojo.kickball2.services.TeamService;
import com.codingdojo.kickball2.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class MainController {
    private final TeamService teamSer;
    private final UserService userSer;
    
    public MainController(TeamService teamSer, UserService userSer) {
        this.teamSer = teamSer;
        this.userSer = userSer;
    }
    
    // ================================ GENERAL ================================ 
    @GetMapping("/")
    public String index(Model model, HttpSession session) {
        if(session.getAttribute("user_id") != null ) {
            return "dashboard.jsp";
        }else {
            model.addAttribute("newUser", new User());
            model.addAttribute("newLogin", new LoginUser());
            return "index.jsp";
        }   
    }
    
    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if(session.getAttribute("user_id") != null ) {
            Long loggedID = (Long) session.getAttribute("user_id");
            User userName = userSer.oneUser(loggedID);
            List<Team> allTeams = teamSer.allTeams();
            model.addAttribute("logged",userName);
            model.addAttribute("allTeams",allTeams);
            return "dashboard.jsp";
        }else {
            return "redirect:/";
        }
    }
    
    // ================================ LOGIN / REGISTRATION ================================
        @PostMapping("/register")
        public String register(@Valid @ModelAttribute("newUser") User newUser, 
                BindingResult result, Model model, HttpSession session) {
            
            userSer.register(newUser, result);
            
            if(result.hasErrors()) {
                model.addAttribute("newLogin", new LoginUser());
                return "index.jsp";
            }
            
            session.setAttribute("user_id", newUser.getId());
            return "redirect:/dashboard";
        }
        
        @PostMapping("/login")
        public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
                BindingResult result, Model model, HttpSession session) {
            User user = userSer.login(newLogin, result);
            if(result.hasErrors()) {
                model.addAttribute("newUser", new User());
                return "index.jsp";
            }
            
            session.setAttribute("user_id", user.getId());
            return "redirect:/dashboard";
        }
        
        @GetMapping("/logout")
        public String dashboard(HttpSession session) {
            session.invalidate();
            return "redirect:/";
        }
    
    // ================================ TEAMS ================================
    @GetMapping("/add/team")
    public String addTeam(Model model, HttpSession session, @ModelAttribute("team") Team team) {
        if(session.getAttribute("user_id") != null ) {
            Long loggedID = (Long) session.getAttribute("user_id");
            model.addAttribute("logged",loggedID);
            return "addTeam.jsp";
        }else {
            return "redirect:/";
        }
    }
    
    @PostMapping("/add/team")
    public String addTeamForm(Model model, @Valid @ModelAttribute("team") Team team, BindingResult result) {
        if(result.hasErrors()) {
            return "addTeam.jsp";
        }else {            
            teamSer.createTeam(team);
            return "redirect:/dashboard";
        }
    }
    
    @GetMapping("/team/{id}")
    public String showTeam(Model model, HttpSession session, @PathVariable("id")Long id) {
        Team team = teamSer.singleTeam(id);
        Long loggedID = (Long) session.getAttribute("user_id");
        model.addAttribute("logged",loggedID);
        model.addAttribute("team",team);
        return "team.jsp";
    }
    
    @GetMapping("/edit/team/{id}")
    public String editTeam(Model model,HttpSession session, @PathVariable("id")Long id, @ModelAttribute("team") Team team) {
        if(session.getAttribute("user_id") != null ) {
            Team thisTeam = teamSer.singleTeam(id);
            Long loggedID = (Long) session.getAttribute("user_id");
            model.addAttribute("logged",loggedID);
            model.addAttribute("thisTeam",thisTeam);
            return "editTeam.jsp";
        }else {
            return "redirect:/";
        }
    }
    
    @PostMapping("/edit/team")
    public String editTeamForm(Model model, @Valid @ModelAttribute("team") Team team, BindingResult result) {
        if(result.hasErrors()) {
            return "editTeam.jsp";
        }else {            
            teamSer.updateTeam(team);
            return "redirect:/dashboard";
        }
    }
    
    @GetMapping("/team")
    public String team(Model model,HttpSession session) {
        if(session.getAttribute("user_id") != null ) {
            return "team.jsp"; 
        }else {
            return "redirect:/";
        }
    }
    @GetMapping("/delete/team/{id}")
    public String deleteTeam(@PathVariable("id") Long id) {
        teamSer.deleteTeam(id);
        return "redirect:/dashboard";
    }}
