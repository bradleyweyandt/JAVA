package com.codingdojo.kickball2.models;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotEmpty(message = "User name cannot be blank")
    @Size(min=2,message="User name must be at least 2 characters")
    private String userName;
    
    @NotEmpty(message = "Email cannot be blank")
    @Email(message="Invalid email format")
    private String email;
    
    @NotEmpty(message = "Password cannot be blank")
    @Size(min=8,max=128,message="Password must be between 8 and 128 characters")
    private String password;
    
    @Transient
    @NotEmpty(message = "Confirm Password cannot be blank")
    @Size(min=8, max=128, message="Confirm Password must be between 8 and 128 characters")
    private String confirm;
    
    @Column(updatable=false)
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date createdAt;
    
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date updatedAt;
    
    // RELATIONSHIPS
    @OneToMany(mappedBy="user", fetch = FetchType.LAZY)
    private List<Team> teams;

    //CONSTRUCTORS
    public User() {
        super();
    }
    
    public User(Long id, @NotEmpty @Size(min = 2, message = "User name cannot be blank") String userName,
            @NotEmpty @Email(message = "Email cannot be blank") String email,
            @NotEmpty @Size(min = 8, max = 128, message = "Password needs to be between 8-128 characters") String password,
            @NotEmpty @Size(min = 8, max = 128, message = "Confirm Password must be between 8 and 128 characters") String confirm,
            Date createdAt, Date updatedAt, List<Team> teams) {
        super();
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.password = password;
        this.confirm = confirm;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.teams = teams;
    }

    public User(@NotEmpty @Size(min = 2, message = "User name cannot be blank") String userName,
            @NotEmpty @Email(message = "Email cannot be blank") String email,
            @NotEmpty @Size(min = 8, max = 128, message = "Password needs to be between 8-128 characters") String password) {
        super();
        this.userName = userName;
        this.email = email;
        this.password = password;
    }

    public User(@NotNull @Size(min = 2, max = 25, message = "User name cannot be blank") String userName,
            @NotEmpty @Email(message = "Email cannot be blank") String email,
            @NotNull @Size(min = 8, max = 128, message = "Password needs to be between 8-128 characters") String password,
            @NotEmpty(message = "Confirm Password is required!") @Size(min = 8, max = 128, message = "Confirm Password must be between 8 and 128 characters") String confirm) {
        super();
        this.userName = userName;
        this.email = email;
        this.password = password;
        this.confirm = confirm;
    }

    public User(Long id, @NotNull @Size(min = 2, max = 25, message = "User name cannot be blank") String userName,
            @NotEmpty @Email(message = "Email cannot be blank") String email,
            @NotNull @Size(min = 8, max = 128, message = "Password needs to be between 8-128 characters") String password,
            @NotEmpty(message = "Confirm Password is required!") @Size(min = 8, max = 128, message = "Confirm Password must be between 8 and 128 characters") String confirm,
            Date createdAt, Date updatedAt) {
        super();
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.password = password;
        this.confirm = confirm;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
    
    
    // GETTERS / SETTERS
    public String getEmail() {
        return email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirm() {
        return confirm;
    }

    public void setConfirm(String confirm) {
        this.confirm = confirm;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    
    public List<Team> getTeams() {
        return teams;
    }

    public void setTeams(List<Team> teams) {
        this.teams = teams;
    }

    @PrePersist
    protected void onCreate(){
        this.createdAt = new Date();
    }
    
    @PreUpdate
    protected void onUpdate(){
        this.updatedAt = new Date();
    }
}
