package com.codingdojo.savetravelsredo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.codingdojo.savetravelsredo.models.Expense;
import com.codingdojo.savetravelsredo.services.ExpenseService;

import jakarta.validation.Valid;

@Controller
public class MainController {

    // injection by Spring
    @Autowired
    private ExpenseService expenseService;

    // redirect to expenses accessing root
    @GetMapping("/")
    public String redirectToExpenses() {
        return "redirect:/expenses";
    }

    // display all expenses and add an empty expense submission
    @GetMapping("/expenses")
    public String displayExpenses(Model model) {
        List<Expense> expenses = expenseService.getAllExpenses();
        model.addAttribute("expenses", expenses);
        model.addAttribute("expense", new Expense());
        return "index.jsp";
    }

    // add new expense
    @PostMapping("/expenses")
    public String addExpense(@Valid @ModelAttribute("expense") Expense expense, BindingResult result, Model model) {
        if (result.hasErrors()) {
            // validation errors, show form with errors
            List<Expense> expenses = expenseService.getAllExpenses();
            model.addAttribute("expenses", expenses);
            return "index.jsp";
        } else {
            // otherwise, create the expense and redirect to expenses page
            expenseService.createExpense(expense);
            return "redirect:/expenses";
        }
    }

    // show edit form for a specific expense
    @GetMapping("/expenses/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("expense", expenseService.findExpense(id));
        return "edit.jsp";
    }

    // update an expense
	@PostMapping("/expenses/edit/{id}")
	public String update(
			@PathVariable("id") Long id, 
			Model model, 
			@Valid @ModelAttribute("expense") Expense expense, 
			BindingResult result) {
		if(result.hasErrors()) {
			model.addAttribute("errorMessage", "Validation error occurred. Please check your inputs.");
			return "edit.jsp";
		}else {
			expenseService.updateExpense(expense);
			return "redirect:/expenses";
		}
	}

    // view details of a specific expense
    @GetMapping("/expenses/{id}")
    public String viewExpenseDetails(@PathVariable("id") Long id, Model model) {
        model.addAttribute("expense", expenseService.findExpense(id));
        return "show.jsp";
    }

    // delete an expense
    @RequestMapping("/expenses/delete/{id}")
    public String deleteExpense(@PathVariable("id") Long id) {
        // find and delete expense, redirect to expenses page
        Expense expense = expenseService.findExpense(id);
        expenseService.deleteExpense(expense);
        return "redirect:/expenses";
    }
    
}
