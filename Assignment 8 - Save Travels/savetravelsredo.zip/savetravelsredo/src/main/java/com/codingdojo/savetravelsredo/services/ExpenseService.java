package com.codingdojo.savetravelsredo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.codingdojo.savetravelsredo.models.Expense;
import com.codingdojo.savetravelsredo.repositories.ExpenseRepository;

@Service
public class ExpenseService {
    private final ExpenseRepository expenseRepository;
    
    public ExpenseService(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }
    // methods
    // retrieve all expenses
    public List<Expense> getAllExpenses(){
        return expenseRepository.findAll();
    }
    
    // create new expense
    public Expense createExpense(Expense expense) {
        return expenseRepository.save(expense);
    }
    
    // find expense ID
    public Expense findExpense(Long id) {
        Optional<Expense> optionalExpense = expenseRepository.findById(id);
        return optionalExpense.orElse(null);
    }
    
    // update existing expense
    public Expense updateExpense(Expense expense) {
        return expenseRepository.save(expense);
    }
    
    // delete existing expense
    public void deleteExpense(Expense expense) {
        expenseRepository.delete(expense);
    }
}