package com.codingdojo.savetravelsredo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

// defining the entity for expenses
@Entity
@Table(name="expenses")
public class Expense {
    // defining the id field
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // defining the name field with validation constraints
    @NotNull
    @Size(min = 1, max = 200, message = "Name cannot be blank")
    private String name;

    // defining the vendor field with validation constraints
    @NotNull
    @Size(min = 1, max = 200, message = "Vendor cannot be blank")
    private String vendor;

    // defining the amount field with validation constraints
    @NotNull(message = "Amount cannot be blank")
    @Min(value = 0, message = "Amount must be greater than zero")
    private Double amount;

    // defining the description field with validation constraints
    @NotNull
    @Size(min = 1, max = 200, message = "Description cannot be blank")
    private String description;

    // default constructor
    public Expense() {
    }

    // getter and setter methods for the id field
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // getter and setter methods for the name field
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // getter and setter methods for the vendor field
    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    // getter and setter methods for the amount field
    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    // getter and setter methods for the description field
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
