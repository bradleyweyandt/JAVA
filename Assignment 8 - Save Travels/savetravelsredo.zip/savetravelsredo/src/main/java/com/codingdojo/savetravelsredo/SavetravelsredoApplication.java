package com.codingdojo.savetravelsredo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SavetravelsredoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SavetravelsredoApplication.class, args);
	}

}
