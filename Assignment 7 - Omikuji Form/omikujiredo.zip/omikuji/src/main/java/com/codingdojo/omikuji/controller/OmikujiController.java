package com.codingdojo.omikuji.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes({"number", "personName", "hobby", "thing", "niceMessage"})
public class OmikujiController {

    @GetMapping("/")
    public String redirectToOmikuji() {
        return "redirect:/omikuji";
    }

    @GetMapping("/omikuji")
    public String showOmikujiForm() {
        return "omikuji-form";
    }

    @PostMapping("/omikuji/process")
    public String processOmikujiForm(@RequestParam int number,
                                     @RequestParam String personName,
                                     @RequestParam String hobby,
                                     @RequestParam String thing,
                                     @RequestParam String niceMessage,
                                     Model model) {
        model.addAttribute("number", number);
        model.addAttribute("personName", personName);
        model.addAttribute("hobby", hobby);
        model.addAttribute("thing", thing);
        model.addAttribute("niceMessage", niceMessage);

        return "redirect:/omikuji/show";
    }

    @GetMapping("/omikuji/show")
    public String showOmikujiResult() {
        return "omikuji-show";
    }
}
