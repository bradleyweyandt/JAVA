package com.codingdojo.dojosandninjasredo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.codingdojo.dojosandninjasredo.models.Dojo;
import com.codingdojo.dojosandninjasredo.models.Ninja;
import com.codingdojo.dojosandninjasredo.repositories.DojoRepository;
import com.codingdojo.dojosandninjasredo.repositories.NinjaRepository;

@Service
public class DojoNinjaService {
    private final NinjaRepository ninjaRepository;
    private final DojoRepository dojoRepository;

    public DojoNinjaService(NinjaRepository ninjaRepository, DojoRepository dojoRepository) {
        this.ninjaRepository = ninjaRepository;
        this.dojoRepository = dojoRepository;
    }

    // Return list of all Dojos
    public List<Dojo> findAllDojos() {
        return (List<Dojo>) dojoRepository.findAll();
    }

    //create a ninja 
    public Ninja createNinja(Ninja ninja) {
        return ninjaRepository.save(ninja);
    }

    //create a dojo
    public Dojo createDojo(Dojo dojo) {
        return dojoRepository.save(dojo);
    }

    //find a dojo 
    public Dojo findDojo(Long id) {
        Optional<Dojo> optionalDojo = dojoRepository.findById(id);
        return optionalDojo.orElse(null);
    }

    //find a ninja
    public Ninja findNinja(Long id) {
        Optional<Ninja> optionalNinja = ninjaRepository.findById(id);
        return optionalNinja.orElse(null);
    }
}
