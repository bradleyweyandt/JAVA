package com.codingdojo.dojosandninjasredo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingdojo.dojosandninjasredo.models.Dojo;
import com.codingdojo.dojosandninjasredo.models.Ninja;
import com.codingdojo.dojosandninjasredo.services.DojoNinjaService;

import jakarta.validation.Valid;

@Controller
public class MainController {

    @Autowired
    DojoNinjaService dojoNinjaService;

    // root URL redirects to the navigation page
    @RequestMapping("/")
    public String redirectToNavigation() {
        return "redirect:/navigation";
    }

    // navigation page mapping
    @RequestMapping("/navigation")
    public String showNavigationPage(Model model) {
        // fetch existing dojos from the service
        List<Dojo> existingDojos = dojoNinjaService.findAllDojos();

        // add the list of existing dojos to the model
        model.addAttribute("dojos", existingDojos);

        // return the navigation.jsp view
        return "navigation.jsp";
    }

    // mapping for displaying the form to add a new dojo
    @RequestMapping("/dojos/new")
    public String showMain(@ModelAttribute("dojo") Dojo dojo) {
        return "index.jsp";
    }

    // post mapping for creating a new dojo
    @PostMapping("/dojos/new")
    public String create(@Valid @ModelAttribute("dojo") Dojo dojo, BindingResult result) {
        if (result.hasErrors()) {
            return "index.jsp";
        } else {
            dojoNinjaService.createDojo(dojo);
            return "redirect:/navigation";
        }
    }

    // mapping for displaying a specific dojo
    @RequestMapping("/dojos/{id}")
    public String showDojo(@PathVariable("id") Long id, Model model) {
        Dojo dojo = dojoNinjaService.findDojo(id);
        model.addAttribute("dojo", dojo);
        return "show.jsp";
    }

    // mapping for displaying the form to add a new ninja
    @RequestMapping("/ninjas/new")
    public String showNinja(@ModelAttribute("ninja") Ninja ninja, Model model) {
        List<Dojo> dojos = dojoNinjaService.findAllDojos();
        model.addAttribute("dojos", dojos);
        return "new.jsp";
    }

    // post mapping for creating a new ninja
    @PostMapping("/ninjas/new")
    public String createNinja(@Valid @ModelAttribute("ninja") Ninja ninja, BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<Dojo> dojos = dojoNinjaService.findAllDojos();
            model.addAttribute("dojos", dojos);
            return "new.jsp";
        } else {
            // Here, you should check if ninja validation passes before saving
            dojoNinjaService.createNinja(ninja);
            return "redirect:/navigation";
        }
    }
}
