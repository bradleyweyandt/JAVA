package com.codingdojo.dojosandninjasredo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojosandninjasredoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojosandninjasredoApplication.class, args);
	}

}
