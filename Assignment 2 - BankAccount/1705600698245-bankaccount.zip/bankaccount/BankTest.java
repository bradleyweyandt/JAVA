public class BankTest {
    public static void main(String[] args) {
        // Create 3 bank accounts
        BankAccount account1 = new BankAccount();
        BankAccount account2 = new BankAccount();
        BankAccount account3 = new BankAccount();

        // Deposit Test
        account1.deposit(1000, "checking");
        account2.deposit(1500, "savings");
        account3.deposit(500, "checking");

        // Display balances after deposits
        System.out.println("Balances after deposits:");
        account1.getBalance();
        account2.getBalance();
        account3.getBalance();

        // Withdrawal Test
        account1.withdraw(200, "checking");
        account2.withdraw(300, "savings");
        account3.withdraw(100, "checking");

        // Display balances after withdrawals
        System.out.println("\nBalances after withdrawals:");
        account1.getBalance();
        account2.getBalance();
        account3.getBalance();

        // Static Test
        System.out.println("\nNumber of Bank Accounts: " + BankAccount.getAccounts());
        System.out.println("Total Money across all accounts: $" + BankAccount.getTotalMoney());
    }
}